// Load saved preferences on page load
window.onload = () => {
  const savedColor = localStorage.getItem('bgColor');
  const savedFontSize = localStorage.getItem('fontSize');
  const isDark = localStorage.getItem('darkMode') === 'true';

  if (savedColor) {
    document.body.style.backgroundColor = savedColor;
    document.getElementById('colorPicker').value = savedColor;
  }

  if (savedFontSize) {
    document.body.style.fontSize = savedFontSize;
    document.getElementById('fontSizeSelect').value = savedFontSize;
  }

  if (isDark) {
    document.body.classList.add('dark-mode');
    document.getElementById('darkModeToggle').checked = true;
  }
};

// Background color change
document.getElementById('colorPicker').addEventListener('input', (e) => {
  const color = e.target.value;
  document.body.style.backgroundColor = color;
  localStorage.setItem('bgColor', color);
});

// Font size change
document.getElementById('fontSizeSelect').addEventListener('change', (e) => {
  const size = e.target.value;
  document.body.style.fontSize = size;
  localStorage.setItem('fontSize', size);
});

// Dark mode toggle
document.getElementById('darkModeToggle').addEventListener('change', (e) => {
  const isDark = e.target.checked;
  if (isDark) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
  localStorage.setItem('darkMode', isDark);
});

// Animate button on click
function handleClick() {
  const btn = document.querySelector('.animate-btn');
  btn.classList.add('bounce');
  setTimeout(() => btn.classList.remove('bounce'), 600);
}